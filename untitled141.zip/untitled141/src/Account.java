import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Account {
    User user;
    private String shcart;
    private String password;
    private int balance;
    private int id;
    private static  int BaseId=1;
    Scanner scanner=new Scanner(System.in);
    ArrayList<Account>Transfer;
    ArrayList<Integer>Transferm;
    public Account(User user, String shcart, String password, int balance) {
        this.user = user;
        this.shcart = shcart;
        this.password = password;
        this.balance = balance;
        this.id=BaseId++;

    }

    public String getShcart() {
        return shcart;
    }

    public void setShcart(String shcart) {
        this.shcart = shcart;
    }
    public void setShcart(){System.out.println("ente rht enew shcart");
        String shcart=scanner.next();
        this.shcart=shcart;

    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPassword(){System.out.println("enter the new password");
        String password=scanner.next();
        this.password=password;

    }
    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }
    public void setbalance(){
        System.out.println("enter the new balnce");
        int balnce=scanner.nextInt();
        this.balance=balnce;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Account{" +
                "user=" + user +
                ", shcart='" + shcart + '\'' +
                ", password='" + password + '\'' +
                ", balance=" + balance +
                ", id=" + id +
                '}';
    }

    public void make(){
        user=new User();
        System.out.println("enter the shcart:");
        this.shcart=scanner.next();
        System.out.println("enter the password:");
        this.password=scanner.next();
        System.out.println("enter the balance:");
        this.balance=scanner.nextInt();
        this.id=BaseId++;
        Transfer=new ArrayList<>();
        Transferm=new ArrayList<>();
    }
    public Account(){make();}

    public void wariz(int m){
        this.balance+=m;
    }
    public void bardasht(int m){

        this.balance-=m;
    }
    public void wariz(){
        System.out.println("enter amount to wariz:");
        int m=scanner.nextInt();
        this.balance+=m;
    }
    public void bardasht(){
        System.out.println("enter the amount to bardasht");
        int m=scanner.nextInt();
        this.balance-=m;

    }

    public ArrayList<Account> getTransfer() {
        return Transfer;
    }

    public void setTransfer(ArrayList<Account> transfer) {
        Transfer = transfer;
    }
}
