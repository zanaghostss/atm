import java.util.Scanner;

public class User {
    private String name;
    private String last_name;
    private String age;
    private int id;
    private static int BaseId=1;

    Scanner scanner=new Scanner(System.in);

    public User(String name, String last_name, String age) {
        this.name = name;
        this.last_name = last_name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void setName(){
        System.out.println("enter the new name:");
        String nmae=scanner.next();
        this.name=nmae;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }
    public void setLast_name(){
        System.out.println("enter the new last name:");
        String last=scanner.next();
        this.last_name=last;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }
    public void setAge(){
        System.out.println("enter he new age");
        String agee=scanner.next();
        this.age=agee;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", last_name='" + last_name + '\'' +
                ", age='" + age + '\'' +
                ", id=" + id +
                '}';
    }

    public void make(){
        System.out.println("enter the name:");
        this.name=scanner.next();
        System.out.println("enter the last name:");
        this.last_name=scanner.next();
        System.out.println("enter the age:");
        this.age=scanner.next();
        this.id=BaseId++;
    }

    public User(){make();}








}
