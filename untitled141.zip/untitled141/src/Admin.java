import java.util.Scanner;

public class Admin {
    User user;
    private String password;
    private String username;
    private static int BaseId=1;
    private int id;
    Scanner scanner=new Scanner(System.in);

    public Admin(User user, String password, String username) {
        this.user = user;
        this.password = password;
        this.username = username;
        this.id=BaseId++;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Admin{" +
                "user=" + user +
                ", password='" + password + '\'' +
                ", username='" + username + '\'' +
                ", id=" + id +
                '}';
    }
    public void make(){
        user=new User();
        System.out.println("enter the password:");
        this.password=scanner.next();
        System.out.println("enter the username");
        this.username=scanner.next();
        this.id=BaseId++;
    }
    public Admin(){make();}
    static Scanner scanner1=new Scanner(System.in);


    static Account Achange=null;
    public static void ChangeAccount(){
        System.out.println("enter shcart");
        String shcart=scanner1.next();
        for (Account account:Login.accounts){
            if(account.getShcart().equals(shcart))
            {
                Achange=account;

            }
        }
    }
    public static void login(){
        while (true){
            System.out.println("1.make a new account");
            System.out.println("2.Login account");
            System.out.println("3.make Admin");
            System.out.println("4.login Admin");
            int ch=scanner1.nextInt();
            switch (ch){
                case 1:
                    Login.accounts.add(new Account());
                    break;
                case 2:
                    DataBAse.loginAccount();
                    break;
                case 3:
                    Login.admins.add(new Admin());
                    break;
                case 4:

                    break;
                default:
                    System.out.println("invaild choice");
                    break;
            }
        }
    }
    public static void ChangeAccount1(){
        while (true){
            System.out.println("1.change user");
            System.out.println("2.change shcart");
            System.out.println("3.change password");
            System.out.println("4.change balance");
            System.out.println("5.Back");
            int ch=scanner1.nextInt();
            switch (ch){
                case 1:
                    ChangeUser();
                    break;
                case 2:
                    Achange.setShcart();
                    break;
                case 3:
                    Achange.setPassword();
                    break;
                case 4:
                    Achange.setbalance();
                    break;
                case 5:
                    login();
                    break;
                default:
                    System.out.println("invaild choice");
                    break;
            }
        }
    }
    public static void ChangeUser(){
        while (true){
            System.out.println("1.change name");
            System.out.println("2.change last name");
            System.out.println("3.change age");
            System.out.println("4.Back");
            int ch=scanner1.nextInt();
            switch (ch){
                case 1:
                    Achange.user.setName();
                    break;
                case 2:
                    Achange.user.setLast_name();
                    break;
                case 3:
                    Achange.user.setAge();
                    break;
                case 4:
                    ChangeAccount1();
                    break;
                default:
                    System.out.println("invaild choice");
                    break;
            }
        }
    }

    public static void RemoveAccount(){
        System.out.println("enter the shcart to Delete");
        String shc=scanner1.next();
        for (Account account:Login.accounts){
            Login.accounts.remove(account);
            System.out.println("account deleted sucessfully");
            break;
        }
    }



}
