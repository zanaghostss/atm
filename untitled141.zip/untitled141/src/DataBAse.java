import java.util.Scanner;



public class DataBAse {
    public DataBAse() {
    }
    static Scanner scanner=new Scanner(System.in);

    static Account logAc=null;
    public static void loginAccount(){
        System.out.println("enter shcart:");
        String shc=scanner.next();
        System.out.println("enter the password:");
        String pasword=scanner.next();
        for (Account account:Login.accounts){
            if(account.getShcart().equals(shc)&&account.getPassword().equals(pasword)){
                System.out.println("Login sucessfully");
                logAc=account;
                LoginAccount1();
                break;
            }
        }
    }
    public static void LoginAccount1(){
        while (true){

            System.out.println("1.show");
            System.out.println("2.bardasht");
            System.out.println("3.wariz");
            System.out.println("4.transfer");
            System.out.println("5.back");


            int ch=scanner.nextInt();
            switch (ch){
                case 1:
                    System.out.println(logAc.toString());
                    break;
                case 2:
                    logAc.bardasht();
                    break;
                case 3:
                    logAc.wariz();
                    break;
                case 4:
                    Transfer();
                    break;
                case 5:
                    login4();
                default:
                    System.out.println("invaild choice");
                    break;
            }
        }

    }



    public static void Transfer(){
        System.out.println("entershcart to transfer:");
        String shcart=scanner.next();
        System.out.println("enter the amount to transfer:");
        int amount=scanner.nextInt();
        for (Account account:Login.accounts){
            if(account.getShcart().equals(shcart)){
                logAc.bardasht(amount);
                account.wariz(amount);

                logAc.Transfer.add(account);
                logAc.Transferm.add(amount);



                System.out.println("Transfer successfully");
            }
        }

    }

    public static void login4(){
        while (true){
            System.out.println("1.make a new account");
            System.out.println("2.Login account");
            System.out.println("3.make Admin");
            System.out.println("4.login Admin");
            int ch=scanner.nextInt();
            switch (ch){
                case 1:
                    Login.accounts.add(new Account());
                    break;
                case 2:
                    DataBAse.loginAccount();
                    break;
                case 3:
                    Login.admins.add(new Admin());
                    break;
                case 4:
                    LoginAdmnin();
                    break;
                default:
                    System.out.println("invaild choice");
                    break;
            }
        }
    }
     static Admin logAd=null;
    public static void LoginAdmnin(){
        System.out.println("enter the username:");
        String username=scanner.next();
        System.out.println("enter the password:");
        String password=scanner.next();
        for (Admin admin:Login.admins){
            if(admin.getUsername().equals(password)&&admin.getPassword().equals(username)){
                System.out.println("Login to admin sucessfully");
                logAd=admin;
                LoginAdmin1();
                break;
            }
        }
    }
    public static void LoginAdmin1(){
        while (true){
            System.out.println("1.show informations");
            System.out.println("2.show personal informations");
            System.out.println("3.chance account");
            System.out.println("4.remove account");
            System.out.println("5.Back");
            int ch=scanner.nextInt();
            switch (ch){
                case 1:
                    for (Account account:Login.accounts){
                        System.out.println(account.toString());
                    }
                    break;
                case 2:
                    System.out.println(logAd.toString());
                    break;
                case 3:
                    Admin.ChangeAccount1();
                    break;
                case 4:
                    Admin.RemoveAccount();
                    break;
                case 5:
                    login4();
                    break;
                default:
                    System.out.println("invaild choice");
                    break;
            }

        }
    }


}
