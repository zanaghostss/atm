import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Login {
    static ArrayList<Account>accounts;
    static ArrayList<Admin>admins;



    public Login() {
        accounts=new ArrayList<>();
        admins=new ArrayList<>();
        login();

    }
     Scanner scanner=new Scanner(System.in);
    public  void login(){
        while (true){
            System.out.println("1.make a new account");
            System.out.println("2.Login account");
            System.out.println("3.make Admin");
            System.out.println("4.login Admin");
            int ch=scanner.nextInt();
            switch (ch){
                case 1:
                    accounts.add(new Account());
                    break;
                case 2:
                    DataBAse.loginAccount();
                    break;
                case 3:
                    admins.add(new Admin());
                    break;
                case 4:
                    DataBAse.LoginAdmnin();
                    break;
                default:
                    System.out.println("invaild choice");
                    break;
            }
        }
    }
}
